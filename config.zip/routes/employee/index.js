"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.employeeRouter = void 0;
var employee_1 = require("./employee");
Object.defineProperty(exports, "employeeRouter", { enumerable: true, get: function () { return __importDefault(employee_1).default; } });
