"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const approvedOrigins = [
    'https://develop.d2nkcnbo67qw9b.amplifyapp.com',
    'http://192.168.1.152:3000',
    'http://localhost:3000'
];
exports.default = approvedOrigins;
